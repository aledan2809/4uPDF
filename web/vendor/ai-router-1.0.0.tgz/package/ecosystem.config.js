module.exports = {
  apps: [{
    name: 'ai-router',
    script: 'server.js',
    cwd: '/opt/ai-router',
    env: {
      NODE_ENV: 'production',
      AI_ROUTER_PORT: '3100',
      AI_ROUTER_HOST: '127.0.0.1',
      AI_ROUTER_BASE: '/opt/ai-router',
    },
    env_file: '/opt/ai-router/.env',
    max_memory_restart: '256M',
    instances: 1,
    autorestart: true,
    watch: false,
    log_date_format: 'YYYY-MM-DD HH:mm:ss',
  }]
};
