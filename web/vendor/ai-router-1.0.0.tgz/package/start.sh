#!/bin/bash
# AI Router — Production startup script
# Loads .env and starts the server

cd /opt/ai-router

# Load environment variables
set -a
source /opt/ai-router/.env
set +a

exec node server.js
