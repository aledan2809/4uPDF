// ═══════════════════════════════════════════════════════
// AI Router — Core Router (smart routing, fallback, health)
// ═══════════════════════════════════════════════════════

import type {
  AIProviderID,
  AIProviderSelection,
  AIRouterConfig,
  AIRequest,
  AIResponse,
  ProviderHealth,
  ProviderRateLimit,
} from "./types";
import { DEFAULT_RATE_LIMITS } from "./types";
import { getProviderConfig, FREE_PROVIDERS } from "./providers/registry";
import { executeProvider } from "./providers/executor";
import { smartSelectProvider } from "./smart-router";
import type { SmartRouteContext, TaskType } from "./smart-router";
import * as fs from "fs";
import * as path from "path";

const DEFAULT_CONFIG: AIRouterConfig = {
  providers: FREE_PROVIDERS,
  defaultProvider: "auto",
  projectName: "unknown",
  maxInputChars: 4000,
  retryDelayMs: 2000,
  maxRetries: 2,
};

export class AIRouter {
  private config: AIRouterConfig;
  private roundRobinIndex: number = 0;
  private healthMap: Map<AIProviderID, ProviderHealth> = new Map();

  constructor(config: Partial<AIRouterConfig> = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config };

    // Initialize health for all configured providers
    for (const id of this.config.providers) {
      this.healthMap.set(id, {
        id,
        healthy: true,
        lastCheck: Date.now(),
        avgLatencyMs: 0,
        successRate: 1,
        totalCalls: 0,
        totalErrors: 0,
      });
    }
  }

  /** Main entry: route an AI request */
  async chat(request: AIRequest): Promise<AIResponse> {
    const provider = request.provider || this.config.defaultProvider;

    if (provider === "auto") {
      return this.smartRoute(request);
    }

    return this.callProvider(provider, request);
  }

  /**
   * Smart Auto mode: analyze request context, score providers,
   * pick the best match, with intelligent fallback ordering.
   * Respects rate limits — avoids providers at warning/critical/exhausted.
   */
  private async smartRoute(request: AIRequest): Promise<AIResponse> {
    const healthy = this.getHealthyProviders();

    // Filter out providers that are near their rate limit
    const resourceStatus = AIRouter.getResourceStatus();

    // Check Claude CLI weekly budget
    let claudeCliWeeklyBlock = false;
    try {
      const budgetPath = path.join("C:/Projects/AIRouter/config", "claude-cli-budget.json");
      if (fs.existsSync(budgetPath)) {
        const budget = JSON.parse(fs.readFileSync(budgetPath, "utf8"));
        const resetDate = new Date(budget.weeklyResetISO);
        const daysLeft = Math.max(0.1, (resetDate.getTime() - Date.now()) / 86400_000);
        const remainingPct = (100 - budget.weeklyUsagePercent) / 100;
        const dailyBudget = remainingPct / daysLeft;
        if (dailyBudget < 0.08) {
          claudeCliWeeklyBlock = true;
          console.log(`[ai-router] Claude CLI weekly budget too low (${Math.round(dailyBudget * 100)}%/day) — skipping for non-essential`);
        }
      }
    } catch {}

    const available = healthy.filter(id => {
      // Weekly budget block for Claude CLI
      if (claudeCliWeeklyBlock && id === "claude") return false;

      // Skip disabled providers (e.g. invalid API key)
      const cfg = getProviderConfig(id);
      if (!cfg.enabled) {
        console.debug(`[ai-router] Skipping ${id} — disabled in registry`);
        return false;
      }

      // Skip providers without API keys (except claude-cli which uses local process)
      if (id !== "claude-cli") {
        if (!process.env[cfg.apiKeyEnvVar]) {
          console.debug(`[ai-router] Skipping ${id} — no API key (${cfg.apiKeyEnvVar})`);
          return false;
        }
      }

      const rs = resourceStatus[id];
      if (!rs) return true;
      if (rs.status === 'exhausted') {
        console.log(`[ai-router] Skipping ${id} — rate limit exhausted (${rs.used}/${rs.limit})`);
        return false;
      }
      if (rs.status === 'critical') {
        console.log(`[ai-router] Skipping ${id} — rate limit critical (${rs.usagePercent * 100}%)`);
        return false;
      }
      return true;
    });

    // Priority provider tracking (Cerebras & SambaNova should be #1 and #2 for TradeInvest)
    const priorityIds = ["cerebras", "sambanova"] as const;
    for (const pid of priorityIds) {
      const inConfig = this.config.providers.includes(pid as AIProviderID);
      const inAvailable = available.includes(pid as AIProviderID);
      if (inConfig && !inAvailable) {
        const cfg = getProviderConfig(pid as AIProviderID);
        const hasKey = (pid as string) === "claude-cli" || !!process.env[cfg.apiKeyEnvVar];
        const rs = resourceStatus[pid];
        const rsStatus = rs ? rs.status : "n/a";
        console.debug(
          `[ai-router] ⚠ Priority provider ${pid} EXCLUDED — ` +
          `hasKey=${hasKey} (${cfg.apiKeyEnvVar}), ` +
          `resourceStatus=${rsStatus}, ` +
          `healthy=${healthy.includes(pid as AIProviderID)}`
        );
      }
    }

    console.debug(`[ai-router] Available providers for ${this.config.projectName}: [${available.join(", ")}] (${available.length}/${this.config.providers.length})`);

    if (available.length === 0) {
      // All at limit — try all anyway as last resort (including rate-limited ones)
      console.warn(`[ai-router] All providers at rate limit — trying anyway`);
      return this.fallbackChain(this.config.providers, request);
    }

    // Build smart routing context from the request
    const context: SmartRouteContext = {
      messages: request.messages,
      taskHint: request.taskHint,
      languageHint: request.languageHint,
      speedVsQuality: request.speedVsQuality,
    };

    const { primary, fallbacks } = smartSelectProvider(
      available,
      context,
      this.healthMap
    );

    try {
      const response = await this.callProvider(primary, request);
      return response;
    } catch {
      // Primary failed — use smart-ordered fallbacks
      if (fallbacks.length === 0) {
        throw new Error(`[ai-router] Provider ${primary} failed and no fallbacks available`);
      }
      return this.fallbackChain(fallbacks, request, primary);
    }
  }

  /** Try providers sequentially until one succeeds */
  private async fallbackChain(
    providers: AIProviderID[],
    request: AIRequest,
    failedFrom?: AIProviderID
  ): Promise<AIResponse> {
    const errors: string[] = [];

    for (const id of providers) {
      try {
        console.log(`[ai-router] Trying ${id} for ${this.config.projectName}`);
        const response = await this.callProvider(id, request);
        if (failedFrom) {
          response.fallback = true;
          response.fallbackFrom = failedFrom;
        }
        return response;
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        console.warn(`[ai-router] ${id} failed: ${msg.substring(0, 100)}`);
        errors.push(`${id}: ${msg.substring(0, 80)}`);
      }
    }

    throw new Error(`[ai-router] All providers failed: ${errors.join(" | ")}`);
  }

  /** Call a specific provider with retry logic */
  private async callProvider(id: AIProviderID, request: AIRequest): Promise<AIResponse> {
    const overrides = this.config.providerOverrides?.[id];
    const config = getProviderConfig(id, overrides);
    const maxRetries = this.config.maxRetries || 2;

    // Truncate input if configured (only truncate string content, skip multimodal)
    const messages = this.config.maxInputChars
      ? request.messages.map((m) => ({
          ...m,
          content: typeof m.content === "string"
            ? m.content.substring(0, this.config.maxInputChars!)
            : m.content,
        }))
      : request.messages;

    let lastError: Error | null = null;

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        const response = await executeProvider({
          config,
          messages,
          model: request.model,
          maxTokens: request.maxTokens,
          temperature: request.temperature,
          jsonMode: request.jsonMode,
        });

        this.recordSuccess(id, response.latencyMs, response.tokenUsage);
        return response;
      } catch (err) {
        lastError = err instanceof Error ? err : new Error(String(err));
        const isRateLimit = lastError.message.includes("429") || lastError.message.includes("rate");
        const isAuth = lastError.message.includes("401") || lastError.message.includes("unauthorized") || lastError.message.includes("Unauthorized");

        if (isAuth) {
          console.warn(`[ai-router] ${id} returned 401 Unauthorized — API key invalid or expired, skipping retries`);
          break; // Don't retry auth errors — key won't fix itself
        }

        if (isRateLimit && attempt < maxRetries) {
          const delay = this.config.retryDelayMs! * (attempt + 1);
          console.log(`[ai-router] ${id} rate limited, retrying in ${delay}ms...`);
          await sleep(delay);
        } else if (attempt < maxRetries) {
          await sleep(500);
        }
      }
    }

    this.recordError(id, lastError?.message || "Unknown error");
    throw lastError || new Error(`[ai-router] ${id} failed after ${maxRetries} retries`);
  }

  /** Get providers that are currently healthy */
  private getHealthyProviders(): AIProviderID[] {
    const now = Date.now();
    const RECOVERY_WINDOW = 60_000; // 1 min cooldown for unhealthy providers

    return this.config.providers.filter((id) => {
      const health = this.healthMap.get(id);
      if (!health) return false;
      if (health.healthy) return true;
      // Allow recovery after cooldown
      if (now - health.lastCheck > RECOVERY_WINDOW) {
        health.healthy = true;
        return true;
      }
      return false;
    });
  }

  private recordSuccess(id: AIProviderID, latencyMs: number, tokenUsage?: { input?: number; output?: number; total?: number }): void {
    const health = this.healthMap.get(id);
    if (!health) return;
    health.totalCalls++;
    health.healthy = true;
    health.lastCheck = Date.now();
    health.avgLatencyMs =
      (health.avgLatencyMs * (health.totalCalls - 1) + latencyMs) / health.totalCalls;
    health.successRate = (health.totalCalls - health.totalErrors) / health.totalCalls;
    this.logMetric(id, true, latencyMs, tokenUsage);
  }

  private recordError(id: AIProviderID, error: string): void {
    const health = this.healthMap.get(id);
    if (!health) return;
    health.totalCalls++;
    health.totalErrors++;
    health.lastError = error;
    health.lastCheck = Date.now();
    health.successRate = (health.totalCalls - health.totalErrors) / health.totalCalls;
    this.logMetric(id, false, 0);

    // Mark unhealthy if error rate > 50%
    if (health.totalCalls >= 3 && health.successRate < 0.5) {
      health.healthy = false;
    }
  }

  /** Get health status for all providers */
  getHealth(): ProviderHealth[] {
    return Array.from(this.healthMap.values());
  }

  /** Get current config */
  getConfig(): AIRouterConfig {
    return { ...this.config };
  }

  /** Get available providers (with API key set) */
  getAvailableProviders(): AIProviderID[] {
    return this.config.providers.filter((id) => {
      const config = getProviderConfig(id);
      return !!process.env[config.apiKeyEnvVar];
    });
  }

  // ── Runtime metrics persistence ──────────────────────────────

  private static readonly METRICS_DIR = "C:/Projects/AIRouter/metrics";

  /** Append a metric entry to the per-project log file */
  private logMetric(providerId: AIProviderID, success: boolean, latencyMs: number, tokenUsage?: { input?: number; output?: number; total?: number }): void {
    try {
      const dir = AIRouter.METRICS_DIR;
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

      const logFile = path.join(dir, `${this.config.projectName.toLowerCase()}.jsonl`);
      const entry = {
        ts: new Date().toISOString(),
        provider: providerId,
        project: this.config.projectName,
        success,
        latencyMs,
        tokens: tokenUsage || null,
      };
      fs.appendFileSync(logFile, JSON.stringify(entry) + "\n", "utf8");
    } catch {
      // Silent fail — metrics are best-effort
    }
  }

  /** Get aggregated runtime metrics for all providers in this project */
  getRuntimeMetrics(): Record<AIProviderID, { calls: number; errors: number; avgLatency: number; successRate: number; totalTokens: number }> {
    return AIRouter.loadMetrics(this.config.projectName);
  }

  /** Static: load metrics for a given project (callable from outside) */
  static loadMetrics(projectName: string): Record<string, { calls: number; errors: number; avgLatency: number; successRate: number; totalTokens: number }> {
    const result: Record<string, { calls: number; errors: number; avgLatency: number; successRate: number; totalTokens: number; _latencySum: number }> = {};

    try {
      const logFile = path.join(AIRouter.METRICS_DIR, `${projectName.toLowerCase()}.jsonl`);
      if (!fs.existsSync(logFile)) return {};

      const lines = fs.readFileSync(logFile, "utf8").trim().split("\n");
      for (const line of lines) {
        if (!line) continue;
        try {
          const entry = JSON.parse(line) as { provider: string; success: boolean; latencyMs: number; tokens?: { total?: number } | null };
          if (!result[entry.provider]) {
            result[entry.provider] = { calls: 0, errors: 0, avgLatency: 0, successRate: 1, totalTokens: 0, _latencySum: 0 };
          }
          const m = result[entry.provider];
          m.calls++;
          if (!entry.success) m.errors++;
          m._latencySum += entry.latencyMs;
          m.avgLatency = Math.round(m._latencySum / m.calls);
          m.successRate = Math.round(((m.calls - m.errors) / m.calls) * 100) / 100;
          m.totalTokens += entry.tokens?.total || 0;
        } catch {}
      }
    } catch {}

    // Clean internal fields
    for (const key of Object.keys(result)) {
      delete (result[key] as Record<string, unknown>)._latencySum;
    }
    return result;
  }

  /** Static: load metrics for ALL projects */
  static loadAllMetrics(): Record<string, Record<string, { calls: number; errors: number; avgLatency: number; successRate: number; totalTokens: number }>> {
    const all: Record<string, Record<string, { calls: number; errors: number; avgLatency: number; successRate: number; totalTokens: number }>> = {};
    try {
      const dir = AIRouter.METRICS_DIR;
      if (!fs.existsSync(dir)) return {};
      const files = fs.readdirSync(dir).filter(f => f.endsWith('.jsonl'));
      for (const f of files) {
        const project = f.replace('.jsonl', '');
        all[project] = AIRouter.loadMetrics(project);
      }
    } catch {}
    return all;
  }

  // ── Resource / Rate Limit Tracking ───────────────────────────

  /**
   * Count calls per provider within a time window, across ALL projects.
   * This gives the global usage for rate limit checking.
   */
  static getProviderUsage(providerId: string, windowMs: number): { count: number; oldest: string | null; newest: string | null } {
    const dir = AIRouter.METRICS_DIR;
    const cutoff = new Date(Date.now() - windowMs).toISOString();
    let count = 0;
    let oldest: string | null = null;
    let newest: string | null = null;

    try {
      if (!fs.existsSync(dir)) return { count: 0, oldest: null, newest: null };
      const files = fs.readdirSync(dir).filter(f => f.endsWith('.jsonl'));

      for (const f of files) {
        const lines = fs.readFileSync(path.join(dir, f), 'utf8').trim().split('\n');
        for (const line of lines) {
          if (!line) continue;
          try {
            const entry = JSON.parse(line) as { ts: string; provider: string; success: boolean };
            if (entry.provider !== providerId) continue;
            if (entry.ts < cutoff) continue;
            count++;
            if (!oldest || entry.ts < oldest) oldest = entry.ts;
            if (!newest || entry.ts > newest) newest = entry.ts;
          } catch {}
        }
      }
    } catch {}

    return { count, oldest, newest };
  }

  /**
   * Get resource status for all providers: usage vs limits, remaining capacity.
   */
  static getResourceStatus(customLimits?: Partial<Record<string, ProviderRateLimit>>): Record<string, {
    used: number;
    limit: number;
    windowMs: number;
    usagePercent: number;
    remaining: number;
    status: 'ok' | 'warning' | 'critical' | 'exhausted';
    estimatedResetMs: number;
  }> {
    const result: Record<string, {
      used: number; limit: number; windowMs: number;
      usagePercent: number; remaining: number;
      status: 'ok' | 'warning' | 'critical' | 'exhausted';
      estimatedResetMs: number;
    }> = {};

    const allProviders = Object.keys(DEFAULT_RATE_LIMITS) as AIProviderID[];

    for (const id of allProviders) {
      const limits = { ...DEFAULT_RATE_LIMITS[id], ...(customLimits?.[id] || {}) };
      const usage = AIRouter.getProviderUsage(id, limits.windowMs);

      const usagePercent = limits.maxRequests > 0 ? usage.count / limits.maxRequests : 0;
      const remaining = Math.max(0, limits.maxRequests - usage.count);

      let status: 'ok' | 'warning' | 'critical' | 'exhausted' = 'ok';
      if (usagePercent >= 1) status = 'exhausted';
      else if (usagePercent >= 0.85) status = 'critical';
      else if (usagePercent >= limits.warningThreshold) status = 'warning';

      // Estimate when the window resets based on oldest call
      let estimatedResetMs = limits.windowMs;
      if (usage.oldest) {
        const oldestTime = new Date(usage.oldest).getTime();
        estimatedResetMs = Math.max(0, (oldestTime + limits.windowMs) - Date.now());
      }

      result[id] = {
        used: usage.count,
        limit: limits.maxRequests,
        windowMs: limits.windowMs,
        usagePercent: Math.round(usagePercent * 100) / 100,
        remaining,
        status,
        estimatedResetMs,
      };
    }

    return result;
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
