// ═══════════════════════════════════════════════════════
// AI Router — Provider Executor (HTTP calls to each API)
// ═══════════════════════════════════════════════════════

import type { AIProviderConfig, AIProviderID, AIMessage, AIContentBlock, AIResponse } from "../types";
import { execSync } from "child_process";

interface ExecOptions {
  config: AIProviderConfig;
  messages: AIMessage[];
  model?: string;
  maxTokens?: number;
  temperature?: number;
  jsonMode?: boolean;
}

/** Extract plain text from a message content (flattens multimodal to text-only) */
function contentToText(content: string | AIContentBlock[]): string {
  if (typeof content === "string") return content;
  return content
    .filter((b): b is { type: "text"; text: string } => b.type === "text")
    .map((b) => b.text)
    .join("\n");
}

/** Check if any message contains multimodal (image) content */
function hasVisionContent(messages: AIMessage[]): boolean {
  return messages.some(
    (m) => Array.isArray(m.content) && m.content.some((b) => b.type === "image")
  );
}

/** Build Gemini `parts` array — preserves image blocks as inline_data for vision models. */
function contentToGeminiParts(content: string | AIContentBlock[]): Array<Record<string, unknown>> {
  if (typeof content === "string") return [{ text: content }];
  return content.map((b) =>
    b.type === "image"
      ? { inline_data: { mime_type: b.source.media_type, data: b.source.data } }
      : { text: b.text }
  );
}

/** Build OpenAI-style multimodal content array — only meaningful for GPT-4o-class models. */
function contentToOpenAIMultimodal(content: string | AIContentBlock[]): unknown {
  if (typeof content === "string") return content;
  const hasImage = content.some((b) => b.type === "image");
  if (!hasImage) return contentToText(content);
  return content.map((b) =>
    b.type === "image"
      ? {
          type: "image_url",
          image_url: { url: `data:${b.source.media_type};base64,${b.source.data}` },
        }
      : { type: "text", text: b.text }
  );
}

/** Execute a request against a specific provider */
export async function executeProvider(opts: ExecOptions): Promise<AIResponse> {
  const { config } = opts;
  const apiKey = process.env[config.apiKeyEnvVar] || "";

  // claude-cli uses CLAUDE_CODE_OAUTH_TOKEN, not an API key
  if (!apiKey && config.id !== "claude-cli" && !(config.id === "claude" && process.env.CLAUDE_CODE_OAUTH_TOKEN)) {
    throw new Error(`Missing API key: ${config.apiKeyEnvVar}`);
  }

  const model = opts.model || config.defaultModel;
  const maxTokens = opts.maxTokens || config.maxTokens;
  const temperature = opts.temperature ?? config.temperature;
  const start = Date.now();

  switch (config.id) {
    case "gemini":
      return executeGemini({ ...opts, model, maxTokens, temperature }, apiKey, start);
    case "claude": {
      // Use Claude CLI (Max subscription, zero API cost) if CLAUDE_CODE_OAUTH_TOKEN is set
      const cliToken = process.env.CLAUDE_CODE_OAUTH_TOKEN;
      if (cliToken) {
        return executeClaudeCLI({ ...opts, model, maxTokens, temperature }, start);
      }
      return executeClaude({ ...opts, model, maxTokens, temperature }, apiKey, start);
    }
    case "claude-cli":
      return executeClaudeCLI({ ...opts, model, maxTokens, temperature }, start);
    case "cohere":
      return executeCohere({ ...opts, model, maxTokens, temperature }, apiKey, start);
    default:
      // OpenAI-compatible: groq, openai, mistral, together, fireworks
      return executeOpenAICompat({ ...opts, model, maxTokens, temperature }, apiKey, start);
  }
}

// ── OpenAI-compatible (Groq, OpenAI, Mistral, Together, Fireworks) ──

async function executeOpenAICompat(
  opts: ExecOptions & { model: string; maxTokens: number; temperature: number },
  apiKey: string,
  start: number
): Promise<AIResponse> {
  const { config, messages, model, maxTokens, temperature, jsonMode } = opts;

  // OpenAI (gpt-4o / gpt-4-vision) supports image_url blocks. Other OpenAI-compat
  // providers (groq, mistral, together, fireworks) don't — for those we flatten
  // to text and the image is silently dropped, same as before.
  const supportsVision = config.id === "openai";
  const body: Record<string, unknown> = {
    model,
    messages: messages.map((m) => ({
      role: m.role,
      content: supportsVision ? contentToOpenAIMultimodal(m.content) : contentToText(m.content),
    })),
    max_tokens: maxTokens,
    temperature,
  };

  if (jsonMode) {
    body.response_format = { type: "json_object" };
  }

  const res = await fetch(config.baseUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
      ...(config.headers || {}),
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => "Unknown error");
    throw new Error(`[${config.id}] ${res.status}: ${errText.substring(0, 200)}`);
  }

  const data = (await res.json()) as Record<string, any>;
  const content = data.choices?.[0]?.message?.content || "";
  const usage = data.usage;

  return {
    content,
    provider: config.id,
    model,
    tokenUsage: usage
      ? { input: usage.prompt_tokens, output: usage.completion_tokens, total: usage.total_tokens }
      : undefined,
    latencyMs: Date.now() - start,
    fallback: false,
  };
}

// ── Google Gemini ──

async function executeGemini(
  opts: ExecOptions & { model: string; maxTokens: number; temperature: number },
  apiKey: string,
  start: number
): Promise<AIResponse> {
  const { messages, model, maxTokens, temperature } = opts;

  // Convert messages to Gemini format
  const systemMsg = messages.find((m) => m.role === "system");
  const nonSystemMsgs = messages.filter((m) => m.role !== "system");

  // Preserve image blocks as inline_data parts so Gemini vision models can read them.
  const geminiContents = nonSystemMsgs.map((m) => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: contentToGeminiParts(m.content),
  }));

  const body: Record<string, unknown> = {
    contents: geminiContents,
    generationConfig: {
      maxOutputTokens: maxTokens,
      temperature,
    },
  };

  if (systemMsg) {
    body.systemInstruction = { parts: [{ text: contentToText(systemMsg.content) }] };
  }

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => "Unknown error");
    throw new Error(`[gemini] ${res.status}: ${errText.substring(0, 200)}`);
  }

  const data = (await res.json()) as Record<string, any>;
  const content = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
  const usage = data.usageMetadata;

  return {
    content,
    provider: "gemini",
    model,
    tokenUsage: usage
      ? { input: usage.promptTokenCount, output: usage.candidatesTokenCount, total: usage.totalTokenCount }
      : undefined,
    latencyMs: Date.now() - start,
    fallback: false,
  };
}

// ── Anthropic Claude ──

async function executeClaude(
  opts: ExecOptions & { model: string; maxTokens: number; temperature: number },
  apiKey: string,
  start: number
): Promise<AIResponse> {
  const { messages, model, maxTokens, temperature } = opts;

  const systemMsg = messages.find((m) => m.role === "system");
  const nonSystemMsgs = messages.filter((m) => m.role !== "system");

  // Claude API natively supports multimodal content blocks (vision + PDFs).
  // Images use `type: "image"`; PDFs must use `type: "document"` (same source schema).
  const body: Record<string, unknown> = {
    model,
    max_tokens: maxTokens,
    temperature,
    messages: nonSystemMsgs.map((m) => ({
      role: m.role,
      content: Array.isArray(m.content)
        ? m.content.map((block) => {
            if (block.type !== "image") return { type: "text", text: block.text };
            const isPdf = block.source.media_type === "application/pdf";
            return isPdf
              ? { type: "document", source: block.source }
              : { type: "image", source: block.source };
          })
        : m.content,
    })),
  };

  if (systemMsg) {
    body.system = contentToText(systemMsg.content);
  }

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => "Unknown error");
    throw new Error(`[claude] ${res.status}: ${errText.substring(0, 200)}`);
  }

  const data = (await res.json()) as Record<string, any>;
  const content = data.content?.[0]?.text || "";
  const usage = data.usage;

  return {
    content,
    provider: "claude",
    model,
    tokenUsage: usage
      ? { input: usage.input_tokens, output: usage.output_tokens, total: (usage.input_tokens || 0) + (usage.output_tokens || 0) }
      : undefined,
    latencyMs: Date.now() - start,
    fallback: false,
  };
}

// ── Claude CLI (Max subscription via subprocess) ──

async function executeClaudeCLI(
  opts: ExecOptions & { model: string; maxTokens: number; temperature: number },
  start: number
): Promise<AIResponse> {
  const { messages, maxTokens } = opts;

  const systemMsg = messages.find((m) => m.role === "system");
  const userMsgs = messages.filter((m) => m.role !== "system");
  const systemText = systemMsg ? contentToText(systemMsg.content) : "";
  const userText = userMsgs.map((m) => contentToText(m.content)).join("\n");

  const prompt = systemText ? `${systemText}\n\n${userText}` : userText;

  // Escape for shell - replace single quotes
  const escaped = prompt.replace(/'/g, "'\\''");

  try {
    const result = execSync(
      `echo '${escaped}' | claude -p --output-format text --max-turns 1 2>/dev/null`,
      {
        timeout: 90000,
        maxBuffer: 1024 * 1024,
        env: { ...process.env },
      }
    );
    const content = result.toString().trim();

    return {
      content,
      provider: "claude-cli",
      model: "claude-max",
      tokenUsage: undefined,
      latencyMs: Date.now() - start,
      fallback: false,
    };
  } catch (err: any) {
    throw new Error(`[claude-cli] ${err.message?.substring(0, 200) || "CLI execution failed"}`);
  }
}

// ── Cohere ──

async function executeCohere(
  opts: ExecOptions & { model: string; maxTokens: number; temperature: number },
  apiKey: string,
  start: number
): Promise<AIResponse> {
  const { messages, model, maxTokens, temperature } = opts;

  // Cohere v2 chat API format
  const body: Record<string, unknown> = {
    model,
    messages: messages.map((m) => ({ role: m.role, content: contentToText(m.content) })),
    max_tokens: maxTokens,
    temperature,
  };

  const res = await fetch("https://api.cohere.com/v2/chat", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => "Unknown error");
    throw new Error(`[cohere] ${res.status}: ${errText.substring(0, 200)}`);
  }

  const data = (await res.json()) as Record<string, any>;
  const content = data.message?.content?.[0]?.text || "";
  const usage = data.usage?.tokens;

  return {
    content,
    provider: "cohere",
    model,
    tokenUsage: usage
      ? { input: usage.input_tokens, output: usage.output_tokens, total: (usage.input_tokens || 0) + (usage.output_tokens || 0) }
      : undefined,
    latencyMs: Date.now() - start,
    fallback: false,
  };
}
