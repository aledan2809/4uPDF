// ═══════════════════════════════════════════════════════
// AI Router — React Dropdown Component
// ═══════════════════════════════════════════════════════

import React from "react";
import type { AIProviderID, AIProviderSelection } from "../types";
import { PROVIDER_REGISTRY } from "../providers/registry";

export interface AIProviderSelectProps {
  /** Current selected value */
  value: AIProviderSelection;
  /** Called when selection changes */
  onChange: (value: AIProviderSelection) => void;
  /** Which providers to show (default: all) */
  providers?: AIProviderID[];
  /** Show only providers that have API keys configured */
  availableOnly?: boolean;
  /** Available provider IDs (from server check) */
  availableProviders?: AIProviderID[];
  /** CSS class for the select element */
  className?: string;
  /** Show tier labels like (Free), (Paid) */
  showTier?: boolean;
  /** Disabled state */
  disabled?: boolean;
  /** Label text above the select */
  label?: string;
}

export function AIProviderSelect({
  value,
  onChange,
  providers,
  availableOnly = false,
  availableProviders,
  className = "h-9 px-3 rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-sm",
  showTier = true,
  disabled = false,
  label,
}: AIProviderSelectProps) {
  const allProviders = providers || (Object.keys(PROVIDER_REGISTRY) as AIProviderID[]);

  const visibleProviders = availableOnly && availableProviders
    ? allProviders.filter((id) => availableProviders.includes(id))
    : allProviders;

  const getLabel = (id: AIProviderID): string => {
    const config = PROVIDER_REGISTRY[id];
    if (!config) return id;
    if (!showTier) return config.name;
    return config.label;
  };

  return (
    <div>
      {label && (
        <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">
          {label}
        </label>
      )}
      <select
        value={value}
        onChange={(e) => onChange((e.target as HTMLSelectElement).value as AIProviderSelection)}
        className={className}
        disabled={disabled}
      >
        <option value="auto">Auto (Round-robin)</option>
        {visibleProviders.map((id) => (
          <option key={id} value={id}>
            {getLabel(id)}
          </option>
        ))}
      </select>
    </div>
  );
}
