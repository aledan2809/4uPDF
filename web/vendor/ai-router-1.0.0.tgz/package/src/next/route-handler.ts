// ═══════════════════════════════════════════════════════
// AI Router — Next.js API Route Handler Factory
// ═══════════════════════════════════════════════════════
//
// Usage in a Next.js API route:
//
//   // app/api/ai/route.ts
//   import { createAIRouteHandler } from "ai-router/next";
//   const handler = createAIRouteHandler({ projectName: "MyProject" });
//   export const POST = handler.POST;
//   export const GET = handler.GET;

import { AIRouter } from "../router";
import { getProjectPreset } from "../config";
import { getProviderConfig, ALL_PROVIDER_IDS } from "../providers/registry";
import type { AIProviderSelection, AIMessage } from "../types";

export interface AIRouteHandlerOptions {
  /** Project name (matches preset configs) */
  projectName: string;
  /** Additional router config overrides */
  routerConfig?: Record<string, unknown>;
}

/** Creates Next.js route handlers for AI routing */
export function createAIRouteHandler(options: AIRouteHandlerOptions) {
  const preset = getProjectPreset(options.projectName);
  const router = new AIRouter({ ...preset, ...options.routerConfig });

  return {
    /** POST /api/ai — Chat with AI */
    POST: async (request: Request) => {
      try {
        const body = await request.json();
        const {
          messages,
          provider = preset.defaultProvider || "auto",
          model,
          maxTokens,
          temperature,
          jsonMode,
        } = body as {
          messages: AIMessage[];
          provider?: AIProviderSelection;
          model?: string;
          maxTokens?: number;
          temperature?: number;
          jsonMode?: boolean;
        };

        if (!messages || !Array.isArray(messages) || messages.length === 0) {
          return Response.json(
            { error: "messages is required and must be a non-empty array" },
            { status: 400 }
          );
        }

        const response = await router.chat({
          messages,
          provider,
          model,
          maxTokens,
          temperature,
          jsonMode,
        });

        return Response.json(response);
      } catch (err) {
        const message = err instanceof Error ? err.message : "Internal error";
        console.error(`[ai-router] ${options.projectName} error:`, message);
        return Response.json({ error: message }, { status: 500 });
      }
    },

    /** GET /api/ai — Provider info & health */
    GET: async () => {
      const health = router.getHealth();
      const available = router.getAvailableProviders();
      const config = router.getConfig();

      // Provider list with availability info
      const providers = ALL_PROVIDER_IDS.map((id) => {
        const cfg = getProviderConfig(id);
        return {
          id: cfg.id,
          name: cfg.name,
          label: cfg.label,
          tier: cfg.tier,
          available: available.includes(id),
          enabled: config.providers.includes(id),
        };
      });

      return Response.json({
        projectName: config.projectName,
        defaultProvider: config.defaultProvider,
        providers,
        health,
        availableProviders: available,
      });
    },

    /** The router instance (for direct use) */
    router,
  };
}
