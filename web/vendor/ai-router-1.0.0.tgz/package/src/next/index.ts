// ═══════════════════════════════════════════════════════
// AI Router — Next.js API Route Handler
// ═══════════════════════════════════════════════════════

export { createAIRouteHandler } from "./route-handler";
export type { AIRouteHandlerOptions } from "./route-handler";
