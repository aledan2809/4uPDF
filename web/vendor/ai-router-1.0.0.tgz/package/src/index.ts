// ═══════════════════════════════════════════════════════
// AI Router — Main Entry Point
// ═══════════════════════════════════════════════════════

// Core
export { AIRouter } from "./router";

// Types
export type {
  AIProviderID,
  AIProviderSelection,
  AIProviderConfig,
  AIRouterConfig,
  AIContentBlock,
  AIMessage,
  AIRequest,
  AIResponse,
  ProviderHealth,
  ProviderRateLimit,
} from "./types";

export { DEFAULT_RATE_LIMITS } from "./types";

// Provider registry
export {
  PROVIDER_REGISTRY,
  getProviderConfig,
  ALL_PROVIDER_IDS,
  FREE_PROVIDERS,
} from "./providers/registry";

// Provider executor
export { executeProvider } from "./providers/executor";

// Config presets
export { getProjectPreset, listPresets, PROJECT_PRESETS } from "./config";

// Smart routing
export { scoreProviders, smartSelectProvider } from "./smart-router";
export type { SmartRouteContext, ProviderScore, TaskType } from "./smart-router";

// Runtime metrics (static method access)
export { AIRouter as AIRouterMetrics } from "./router";
