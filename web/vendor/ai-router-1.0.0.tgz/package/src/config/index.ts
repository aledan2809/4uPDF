// ═══════════════════════════════════════════════════════
// AI Router — Project-specific Preset Configs
// ═══════════════════════════════════════════════════════
//
// Provider order: FREE first (fallback priority), then PAID last.
// Groq is now PAID — moved to end with other paid providers.
// Default for all projects: "auto" (round-robin on free providers).

import type { AIRouterConfig, AIProviderID } from "../types";

// Canonical order: free → freemium → paid
const FREE_FIRST: AIProviderID[] = ["gemini", "mistral", "cohere", "together", "fireworks", "groq", "openai", "claude"];

/**
 * Recommended defaults per project.
 * Each project can override: default provider, provider list, model overrides.
 */
export const PROJECT_PRESETS: Record<string, Partial<AIRouterConfig>> = {
  // Source: Claude understands Romanian suppliers best
  source: {
    projectName: "Source",
    defaultProvider: "claude",
    providers: ["gemini", "mistral", "cohere", "together", "fireworks", "claude", "openai", "groq"],
  },

  // TradeInvest: Gemini as default (Groq no longer free), free providers first
  tradeinvest: {
    projectName: "TradeInvest",
    defaultProvider: "auto",
    providers: ["cerebras", "sambanova", "mistral", "perplexity", "gemini", "cohere", "hyperbolic", "openrouter", "fireworks", "deepinfra", "novita", "lepton", "groq", "openai", "claude-cli", "claude"],
    // Together.ai removed — API key invalid (401), wastes fallback slot. Re-add when key is renewed.
  },

  // BlocHub: Gemini for general content
  blochub: {
    projectName: "BlocHub",
    defaultProvider: "gemini",
    providers: ["gemini", "mistral", "cohere", "together", "fireworks", "openai", "claude", "groq"],
  },

  // UtilajHub: Mistral (EU GDPR) for Romanian marketplace
  utilajhub: {
    projectName: "UtilajHub",
    defaultProvider: "mistral",
    providers: ["mistral", "gemini", "cohere", "together", "fireworks", "openai", "claude", "groq"],
  },

  // eCabinet: Gemini for document processing
  ecabinet: {
    projectName: "eCabinet",
    defaultProvider: "gemini",
    providers: ["gemini", "mistral", "cohere", "together", "fireworks", "openai", "claude", "groq"],
  },

  // AVE: General purpose, auto round-robin on free providers
  ave: {
    projectName: "AVE",
    defaultProvider: "auto",
    providers: FREE_FIRST,
  },

  // 4uPDF: Cohere for text extraction/summarization
  "4updf": {
    projectName: "4uPDF",
    defaultProvider: "cohere",
    providers: ["cohere", "gemini", "mistral", "together", "fireworks", "openai", "claude", "groq"],
  },

  // TeInformez: Romanian news platform — Mistral (EU/GDPR) preferred, free providers first
  teinformez: {
    projectName: "TeInformez",
    defaultProvider: "auto",
    providers: ["cerebras", "sambanova", "gemini", "mistral", "cohere", "openrouter", "perplexity", "together", "fireworks", "novita", "lepton", "groq", "openai", "claude-cli", "claude", "deepinfra", "hyperbolic"],
  },
  // utilajhubnext (auto-added from Master dashboard)
  utilajhubnext: {
    projectName: "utilajhubnext",
    defaultProvider: "auto",
    providers: ["cerebras", "gemini", "mistral", "cohere", "sambanova", "openrouter", "together", "fireworks", "groq", "openai", "claude-cli", "claude", "perplexity", "deepinfra", "novita", "lepton", "hyperbolic"],
  },


  // 4pro-client: general purpose, auto round-robin
  "4proclient": {
    projectName: "4pro-client",
    defaultProvider: "auto",
    providers: FREE_FIRST,
  },

  // 4pro-identity: identity/auth service
  "4proidentity": {
    projectName: "4pro-identity",
    defaultProvider: "auto",
    providers: FREE_FIRST,
  },

  // 4pro-landing: landing pages
  "4prolanding": {
    projectName: "4pro-landing",
    defaultProvider: "auto",
    providers: FREE_FIRST,
  },

  // 4pro-biz: Romanian business crawling & categorization
  "4probiz": {
    projectName: "4pro-biz",
    defaultProvider: "auto",
    providers: ["gemini", "mistral", "cohere", "together", "fireworks", "openai", "claude", "groq"],
  },

  // Tester: AI-powered testing (needs vision-capable providers)
  tester: {
    projectName: "Tester",
    defaultProvider: "claude",
    providers: ["claude", "gemini", "openai", "mistral", "cohere", "together", "fireworks", "groq"],
  },

  // MarketingAutomation: content generation
  marketingautomation: {
    projectName: "MarketingAutomation",
    defaultProvider: "auto",
    providers: ["gemini", "mistral", "cohere", "together", "fireworks", "openai", "claude", "groq"],
  },

  // SEAP: Romanian public procurement analysis
  seap: {
    projectName: "SEAP",
    defaultProvider: "auto",
    providers: ["mistral", "gemini", "cohere", "together", "fireworks", "openai", "claude", "groq"],
  },

  // Feedback-Hub: feedback analysis
  feedbackhub: {
    projectName: "Feedback-Hub",
    defaultProvider: "auto",
    providers: FREE_FIRST,
  },

  // Scrap-module: web scraping with AI extraction
  scrapmodule: {
    projectName: "Scrap-module",
    defaultProvider: "auto",
    providers: ["gemini", "mistral", "cohere", "together", "fireworks", "openai", "claude", "groq"],
  },

  // E-mail Guru: email classification
  emailguru: {
    projectName: "E-mail Guru",
    defaultProvider: "auto",
    providers: FREE_FIRST,
  },

  // ocr-model: OCR validation
  ocrmodel: {
    projectName: "ocr-model",
    defaultProvider: "auto",
    providers: FREE_FIRST,
  },

  // STT: speech-to-text (Whisper uses OpenAI directly, router for future chat)
  stt: {
    projectName: "STT",
    defaultProvider: "auto",
    providers: FREE_FIRST,
  },

  // Meeting-rec: meeting recording (Whisper direct, router for future chat)
  meetingrec: {
    projectName: "Meeting-rec",
    defaultProvider: "auto",
    providers: FREE_FIRST,
  },

  // OpenAI: coding agent (prefers OpenAI for model compatibility)
  openai: {
    projectName: "OpenAI",
    defaultProvider: "openai",
    providers: ["openai", "gemini", "mistral", "cohere", "together", "fireworks", "claude", "groq"],
  },

  // eProfit: Romanian accounting/tax — Gemini for OCR, Mistral for EU compliance
  eprofit: {
    projectName: "eProfit",
    defaultProvider: "gemini",
    providers: ["gemini", "mistral", "cohere", "together", "fireworks", "openai", "claude", "groq"],
  },

  // HeadHunter: recruitment/HR
  headhunter: {
    projectName: "HeadHunter",
    defaultProvider: "auto",
    providers: FREE_FIRST,
  },

  // GCalendar, GMaps, KB, Stripe, Telegram, whatsapp — general purpose
  gcalendar: { projectName: "GCalendar", defaultProvider: "auto", providers: FREE_FIRST },
  gmaps: { projectName: "GMaps", defaultProvider: "auto", providers: FREE_FIRST },
  kb: { projectName: "KB", defaultProvider: "auto", providers: FREE_FIRST },
  stripe: { projectName: "Stripe", defaultProvider: "auto", providers: FREE_FIRST },
  telegram: { projectName: "Telegram", defaultProvider: "auto", providers: FREE_FIRST },
  whatsapp: { projectName: "whatsapp", defaultProvider: "auto", providers: FREE_FIRST },
  websiteguru: { projectName: "website-guru", defaultProvider: "auto", providers: FREE_FIRST },
  sms: { projectName: "SMS", defaultProvider: "auto", providers: ["cerebras", "sambanova", "gemini", "mistral", "cohere", "openrouter", "together", "fireworks", "groq", "openai", "claude-cli", "claude"] },

  // WebAuditor: web auditing tool — free providers first, Claude fallback
  webauditor: {
    projectName: "WebAuditor",
    defaultProvider: "auto",
    providers: ["gemini", "mistral", "cohere", "together", "fireworks", "groq", "openai", "claude"],
  },
  promptarchitect: { projectName: "Prompt-Architect", defaultProvider: "auto", providers: FREE_FIRST },
  myholiday: { projectName: "Myholiday", defaultProvider: "auto", providers: FREE_FIRST },
  devlearningplatform: { projectName: "DevLearningPlatform", defaultProvider: "auto", providers: FREE_FIRST },

  // ML (MegaLaunch): master roadmap — free providers first, Claude fallback
  ml: {
    projectName: "ML",
    defaultProvider: "auto",
    providers: ["cerebras", "sambanova", "gemini", "mistral", "cohere", "openrouter", "together", "fireworks", "groq", "openai", "claude-cli", "claude"],
  },

  // PMB: Romanian public procurement — free providers first, Claude fallback
  pmb: {
    projectName: "PMB",
    defaultProvider: "auto",
    providers: ["cerebras", "sambanova", "gemini", "mistral", "cohere", "openrouter", "together", "fireworks", "groq", "openai", "claude-cli", "claude"],
  },

  // Music: AI music generator — free providers first, Claude fallback
  music: {
    projectName: "Music",
    defaultProvider: "auto",
    providers: ["gemini", "mistral", "cohere", "together", "fireworks", "groq", "openai", "claude"],
  },

  // Suno API: music generation platform — free providers first, Claude fallback
  suno: {
    projectName: "Suno",
    defaultProvider: "auto",
    providers: ["gemini", "mistral", "cohere", "together", "fireworks", "groq", "openai", "claude"],
  },

  // PDF-split: OCR-based PDF splitting — free providers first, Claude fallback
  pdfsplit: {
    projectName: "PDF-split",
    defaultProvider: "auto",
    providers: ["cerebras", "sambanova", "gemini", "mistral", "cohere", "openrouter", "together", "fireworks", "groq", "openai", "claude-cli", "claude"],
  },

  // knowbest: knowledge base SaaS — free providers first, Claude fallback for complex tasks
  knowbest: {
    projectName: "knowbest",
    defaultProvider: "auto",
    providers: FREE_FIRST,
  },

  // Default: balanced round-robin (free providers first, paid last)
  default: {
    projectName: "Default",
    defaultProvider: "auto",
    providers: FREE_FIRST,
  },
};

/** Get project config by name (case-insensitive), falls back to default */
export function getProjectPreset(projectName: string): Partial<AIRouterConfig> {
  const key = projectName.toLowerCase().replace(/[-_\s]/g, "");
  return PROJECT_PRESETS[key] || { ...PROJECT_PRESETS.default, projectName };
}

/** List all available presets */
export function listPresets(): string[] {
  return Object.keys(PROJECT_PRESETS);
}
