# AIRouter — Multi-Provider AI Routing Library (Core Ecosystem)

## Overview
Reusable multi-provider AI router. Round-robin with free-first strategy, fallback chains. Consumed by 30+ projects.

## Stack
- TypeScript, tsup (CJS+ESM+DTS)
- React components (provider dropdown)
- Next.js API handler (ready-made route)

## Build
```bash
npm run build    # CJS + ESM + types
```

## Providers (18+)
Claude, OpenAI, Gemini, Groq, Mistral, Cohere, Together, Fireworks, DeepInfra, OpenRouter, Cerebras, SambaNova, Perplexity, CloudFlare Workers AI, Ollama (local), +more

## Key Exports
- `AIRouter` class — main router
- `getProjectPreset(name)` — project-specific config
- `FREE_PROVIDERS` — zero-cost provider list
- React `<ProviderSelector>` component
- Next.js `createAIHandler()` — drop-in API route

## CRITICAL — HIGH IMPACT
- **This library is consumed by 30+ projects** — any breaking change cascades everywhere
- **DO NOT** change public API signatures without versioning
- **DO NOT** remove providers from the registry
- **DO NOT** modify preset config structure

## Key Files
- `src/providers/executor.ts` — HTTP calls to each provider
- `src/config/index.ts` — Provider registry + model configs
- `src/index.ts` — Main exports


## Governance Reference
See: `Master/knowledge/MASTER_SYSTEM.md` §1-§5. This project follows Master governance; do not duplicate rules.
NO-TOUCH CRITIC: see `AUDIT_GAPS.md` at project root for propose-confirm-apply protocol (Master `CLAUDE.md` §2d).
