#!/usr/bin/env node
import fs from 'fs';
import path from 'path';

function loadKeys() {
  const vars = {};
  const credDir = 'C:/Projects/Master/credentials';
  try {
    const files = fs.readdirSync(credDir).filter(f => f.endsWith('.env'));
    for (const f of files) {
      const content = fs.readFileSync(path.join(credDir, f), 'utf8');
      for (const line of content.split('\n')) {
        if (line.trimStart().startsWith('#')) continue;
        const m = line.match(/^([A-Z_]+)=["']?([^"'\n]+)/);
        if (m) vars[m[1]] = m[2];
      }
    }
  } catch {}
  for (const p of ['C:/Projects/Master/.env', 'C:/Projects/Master/.env.local']) {
    try {
      const content = fs.readFileSync(p, 'utf8');
      for (const line of content.split('\n')) {
        if (line.trimStart().startsWith('#')) continue;
        const m = line.match(/^([A-Z_]+)=["']?([^"'\n]+)/);
        if (m) vars[m[1]] = m[2];
      }
    } catch {}
  }
  return vars;
}

const keys = loadKeys();
const METRICS_DIR = 'C:/Projects/AIRouter/metrics';
if (!fs.existsSync(METRICS_DIR)) fs.mkdirSync(METRICS_DIR, { recursive: true });

const providers = [
  { id: 'groq',       envVar: 'GROQ_API_KEY',       url: 'https://api.groq.com/openai/v1/chat/completions',             model: 'llama-3.3-70b-versatile',    type: 'openai' },
  { id: 'gemini',     envVar: 'GEMINI_API_KEY',      url: null,                                                          model: 'gemini-2.0-flash',           type: 'gemini' },
  { id: 'claude',     envVar: 'ANTHROPIC_API_KEY',   url: 'https://api.anthropic.com/v1/messages',                       model: 'claude-haiku-4-5-20251001',  type: 'claude' },
  { id: 'openai',     envVar: 'OPENAI_API_KEY',      url: 'https://api.openai.com/v1/chat/completions',                  model: 'gpt-4o-mini',                type: 'openai' },
  { id: 'mistral',    envVar: 'MISTRAL_API_KEY',     url: 'https://api.mistral.ai/v1/chat/completions',                  model: 'mistral-small-latest',       type: 'openai' },
  { id: 'cohere',     envVar: 'COHERE_API_KEY',      url: 'https://api.cohere.com/v2/chat',                              model: 'command-r-08-2024',          type: 'cohere' },
  { id: 'together',   envVar: 'TOGETHER_API_KEY',    url: 'https://api.together.xyz/v1/chat/completions',                model: 'meta-llama/Llama-3.3-70B-Instruct-Turbo', type: 'openai' },
  { id: 'fireworks',  envVar: 'FIREWORKS_API_KEY',   url: 'https://api.fireworks.ai/inference/v1/chat/completions',       model: 'accounts/fireworks/models/llama-v3p3-70b-instruct', type: 'openai' },
  { id: 'cerebras',   envVar: 'CEREBRAS_API_KEY',    url: 'https://api.cerebras.ai/v1/chat/completions',                 model: 'llama3.1-8b',                type: 'openai' },
  { id: 'openrouter', envVar: 'OPENROUTER_API_KEY',  url: 'https://openrouter.ai/api/v1/chat/completions',               model: 'meta-llama/llama-3.3-70b-instruct:free', type: 'openai' },
  { id: 'sambanova',  envVar: 'SAMBANOVA_API_KEY',   url: 'https://api.sambanova.ai/v1/chat/completions',                model: 'Meta-Llama-3.3-70B-Instruct', type: 'openai' },
  { id: 'perplexity', envVar: 'PERPLEXITY_API_KEY',  url: 'https://api.perplexity.ai/chat/completions',                  model: 'sonar',                      type: 'openai' },
];

async function pingProvider(p) {
  const apiKey = keys[p.envVar];
  if (!apiKey) return { id: p.id, status: 'no_key', latencyMs: 0 };

  const start = Date.now();
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 15000);

  try {
    let res;
    if (p.type === 'gemini') {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${p.model}:generateContent?key=${apiKey}`;
      res = await fetch(url, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contents: [{ parts: [{ text: 'Say OK' }] }], generationConfig: { maxOutputTokens: 5 } }),
        signal: ctrl.signal,
      });
    } else if (p.type === 'claude') {
      res = await fetch(p.url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({ model: p.model, max_tokens: 5, messages: [{ role: 'user', content: 'Say OK' }] }),
        signal: ctrl.signal,
      });
    } else if (p.type === 'cohere') {
      res = await fetch(p.url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
        body: JSON.stringify({ model: p.model, messages: [{ role: 'user', content: 'Say OK' }], max_tokens: 5 }),
        signal: ctrl.signal,
      });
    } else {
      res = await fetch(p.url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
        body: JSON.stringify({ model: p.model, messages: [{ role: 'user', content: 'Say OK' }], max_tokens: 5 }),
        signal: ctrl.signal,
      });
    }
    clearTimeout(timer);
    const latencyMs = Date.now() - start;
    const body = await res.text();

    let success = res.ok;
    let tokens = null;
    let status = 'active';

    if (!res.ok) {
      const lower = body.toLowerCase();
      if (lower.includes('credit') || lower.includes('quota') || lower.includes('billing') || lower.includes('insufficient') || res.status === 402) {
        status = 'no_credit';
      } else if (res.status === 401 || res.status === 403 || lower.includes('invalid') || lower.includes('unauthorized')) {
        status = 'invalid';
      } else if (res.status === 429) {
        status = 'rate_limited';
      } else {
        status = 'error';
      }
      success = false;
    } else {
      try {
        const json = JSON.parse(body);
        if (json.usage) tokens = { input: json.usage.prompt_tokens, output: json.usage.completion_tokens, total: json.usage.total_tokens };
        else if (json.usageMetadata) tokens = { input: json.usageMetadata.promptTokenCount, output: json.usageMetadata.candidatesTokenCount, total: json.usageMetadata.totalTokenCount };
      } catch {}
    }

    const entry = { ts: new Date().toISOString(), provider: p.id, project: '_healthcheck', success, latencyMs, tokens };
    fs.appendFileSync(path.join(METRICS_DIR, '_healthcheck.jsonl'), JSON.stringify(entry) + '\n', 'utf8');

    return { id: p.id, status, latencyMs, tokens, error: !res.ok ? body.substring(0, 120) : undefined };
  } catch (err) {
    clearTimeout(timer);
    const latencyMs = Date.now() - start;
    const entry = { ts: new Date().toISOString(), provider: p.id, project: '_healthcheck', success: false, latencyMs, tokens: null };
    fs.appendFileSync(path.join(METRICS_DIR, '_healthcheck.jsonl'), JSON.stringify(entry) + '\n', 'utf8');
    return { id: p.id, status: 'error', latencyMs, error: err.message?.substring(0, 100) };
  }
}

console.log('Pinging all providers...\n');

for (const p of providers) {
  process.stdout.write(`  ${p.id.padEnd(12)} ... `);
  const r = await pingProvider(p);
  const icon = r.status === 'active' ? 'OK' : r.status === 'no_key' ? 'NO_KEY' : r.status === 'no_credit' ? 'NO_CREDIT' : r.status === 'invalid' ? 'INVALID' : r.status === 'rate_limited' ? 'RATE_LIM' : 'ERROR';
  const extra = r.tokens ? `(${r.tokens.total} tok)` : '';
  const err = r.error ? ` | ${r.error.substring(0, 80)}` : '';
  console.log(`${icon.padEnd(10)} ${String(r.latencyMs).padStart(5)}ms ${extra}${err}`);
}

console.log('\nDone. Metrics saved to', path.join(METRICS_DIR, '_healthcheck.jsonl'));
