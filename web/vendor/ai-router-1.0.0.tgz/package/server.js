#!/usr/bin/env node
// ═══════════════════════════════════════════════════════
// AI Router — Standalone HTTP Microservice
// ═══════════════════════════════════════════════════════
// Wraps the AIRouter library as a standalone HTTP server.
// WordPress integration sends: {system, prompt, maxTokens, ...}
// This server converts to AIRouter format and returns {text, provider, model}.

const http = require("http");
const { AIRouter } = require("./dist/router");
const { getProjectPreset } = require("./dist/config");

const PORT = parseInt(process.env.AI_ROUTER_PORT || "3100", 10);
const HOST = process.env.AI_ROUTER_HOST || "127.0.0.1";

// Parse incoming request body
function parseBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on("data", (chunk) => chunks.push(chunk));
    req.on("end", () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString()));
      } catch (e) {
        reject(new Error("Invalid JSON body"));
      }
    });
    req.on("error", reject);
  });
}

// Send JSON response
function sendJSON(res, statusCode, data) {
  res.writeHead(statusCode, { "Content-Type": "application/json" });
  res.end(JSON.stringify(data));
}

// Router instances cache (per project)
const routers = new Map();

function getRouter(projectName) {
  const key = (projectName || "default").toLowerCase();
  if (!routers.has(key)) {
    const preset = getProjectPreset(key);
    routers.set(key, new AIRouter({ ...preset, projectName: projectName || "default" }));
  }
  return routers.get(key);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${HOST}:${PORT}`);
  const pathname = url.pathname;

  // CORS headers (localhost only)
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") {
    res.writeHead(204);
    res.end();
    return;
  }

  // Health check
  if (pathname === "/health" && req.method === "GET") {
    return sendJSON(res, 200, { status: "ok", uptime: process.uptime() });
  }

  // GET /api/ai/chat — provider info
  if (pathname === "/api/ai/chat" && req.method === "GET") {
    const router = getRouter("default");
    const health = router.getHealth();
    const available = router.getAvailableProviders();
    return sendJSON(res, 200, {
      status: "ok",
      availableProviders: available,
      health,
    });
  }

  // POST /api/ai/chat — main endpoint
  if (pathname === "/api/ai/chat" && req.method === "POST") {
    try {
      const body = await parseBody(req);

      // Build messages array from WordPress format (system + prompt)
      // or accept standard messages array
      let messages;
      if (body.messages && Array.isArray(body.messages)) {
        messages = body.messages;
      } else if (body.prompt) {
        messages = [];
        if (body.system) {
          messages.push({ role: "system", content: body.system });
        }
        messages.push({ role: "user", content: body.prompt });
      } else {
        return sendJSON(res, 400, { error: "Either 'messages' array or 'prompt' string is required" });
      }

      const projectName = body.projectName || "default";
      const router = getRouter(projectName);

      const response = await router.chat({
        messages,
        provider: body.provider || "auto",
        model: body.model,
        maxTokens: body.maxTokens,
        temperature: body.temperature,
        jsonMode: body.jsonMode,
        languageHint: body.languageHint,
        taskHint: body.taskHint,
        speedVsQuality: body.speedVsQuality,
      });

      // Return in WordPress-expected format: {text, provider, model}
      return sendJSON(res, 200, {
        text: response.content,
        provider: response.provider,
        model: response.model,
        tokenUsage: response.tokenUsage,
        latencyMs: response.latencyMs,
        fallback: response.fallback,
        fallbackFrom: response.fallbackFrom,
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : "Internal error";
      console.error(`[ai-router-service] Error:`, message);
      return sendJSON(res, 500, { error: message });
    }
  }

  // 404
  sendJSON(res, 404, { error: "Not found" });
});

server.listen(PORT, HOST, () => {
  console.log(`[ai-router-service] Running on http://${HOST}:${PORT}`);
  console.log(`[ai-router-service] Endpoint: POST http://${HOST}:${PORT}/api/ai/chat`);
  console.log(`[ai-router-service] Health:   GET  http://${HOST}:${PORT}/health`);
});
